<?php
namespace Home\Controller;
//use Think\Controller;
use Tools\HomeController;

class CategoryController extends HomeController{
    //分类列表
    function showlist(){
        $daohang = array(
            'first'=>'分类管理',
            'second'=>'分类列表',
            'third'=>'添加',
            'third_url'=>U('tianjia'),
        );
        $this -> assign('daohang',$daohang);

        $goods = D('Category');
        $info = $goods ->order('cat_id desc')-> select();

        
        
        
        //数据的分页
        //先查询有多少记录
        $count = $goods -> count(); //返回值是数字
        //告诉分页类，一共有多少个记录和每页显示的记录数量
        $page = new \Think\Page($count,5);  //不需要参数
        //配置
        $page -> setConfig('first','首页');
        $page -> setConfig('prev','上一页');
        $page -> setConfig('next','下一页');
        $page -> setConfig('last','末页');
        $show = $page -> show();
        //查询
        $info = $goods -> limit($page -> firstRow.','.$page -> listRows) -> select();
        
        //$qq = new  \Model\QqModel();
        //show_bug($qq);
        //echo __SELF__;
        //echo __MODULE__;
        
        //把变量传递给模版
        $this -> assign('show',$show);

        //获得分类信息
        $info = D('Category')
            ->order('cat_path')
            ->select();
        $this -> assign('info',$info);

        $this -> display();
    }
    
    
    //添加分类
    function tianjia(){
        if(IS_POST){
            //dump($_POST);
            //1）先执行insert语句填充两个(name/pid)字段内容
            //2）再执行update语句把path/level给组好并更新过来
            //   具体在_after_insert()
            $category = new \Model\CategoryModel();
            $shuju = $category->create();
            if($category->add($shuju)){
                $this -> success('添加分类成功',U('showlist'),1);
            }else{
                $this -> error('添加分类失败',U('tianjia'),1);
            }
        }else{
            $daohang = array(
                'first'=>'分类管理',
                'second'=>'添加分类',
                'third'=>'返回',
                'third_url'=>U('showlist'),
            );
            $this -> assign('daohang',$daohang);
            /****获得供选取的上级(前两个级别)分类信息****/
            $catinfo = D('Category')
                ->where(array('cat_level'=>array('in','0,1')))
                ->order('cat_path')
                ->select();
            $this -> assign('catinfo',$catinfo);
            /****获得供选取的上级(前两个级别)分类信息****/

            $this -> display();
        }
    }

    //根据父级获得子级的分类信息
    function getCatByPid(){
        $cat_id = I('get.cat_id');

        //查询子级分类信息
        $catinfo = D('Category')
            -> where(array('cat_pid'=>$cat_id))
            -> select();
        echo json_encode($catinfo); //[json,json,json..]
    }

    //商品修改
    function upd(){
        $goods_id = I('get.cat_id');
        $goods = new \Model\CategoryModel();
        if(IS_POST){
            //dump($_POST);
            //修改商品普通信息处理
            $shuju = $goods -> create();
            $shuju['upd_time'] = time();

            //富文本编辑器内容特殊处理
            $shuju['goods_introduce'] = \fanXSS($_POST['goods_introduce']);

            $this -> deal_logo($shuju); //实现商品logo图片处理
            $this -> deal_pics($shuju['cat_id']); //实现相册上传处理

            if($goods->save($shuju)){
                $this -> success('修改商品成功',U('showlist'),1);
            }else{
                $this -> error('修改商品失败',U('upd',array('cat_id'=>$goods_id)),1);
            }
        }else{
            $daohang = array(
                'first'=>'商品分类',
                'second'=>'修改商品',
                'third'=>'返回',
                'third_url'=>U('showlist'),
            );
            $this -> assign('daohang',$daohang);
            //根据$goods_id获得被修改商品的信息
            $info = $goods->find($goods_id);

            /****相册图片信息sp_goods_pics****/
            $picsinfo = D('GoodsPics')
                ->where(array('goods_id'=>$goods_id))
                ->select();
            $this -> assign('picsinfo',$picsinfo);
            /****相册图片信息****/

            /****获得“类型”并传递给模板****/
            $typeinfo = D('Type')->select();
            $this -> assign('typeinfo',$typeinfo);
            /****获得“类型”并传递给模板****/

            /****获得“第一级分类信息”并传递给模板****/
            $catinfoA = D('Category')
                ->where(array('cat_level'=>0))
                ->select();
            $this -> assign('catinfoA',$catinfoA);
            /****获得“第一级分类信息”并传递给模板****/

            /****获得商品的所有扩展分类信息****/
            $ext = D('GoodsCat')
                ->where(array('goods_id'=>$goods_id))
                ->field('group_concat(cat_id) as extids')
                ->find();
            //dump($ext);//array(1) {["extids"] => string(3) "5,6"}
            $extcatids = $ext['extids'];
            $this -> assign('extcatids',$extcatids);
            /****获得商品的所有扩展分类信息****/

            $this -> assign('info',$info);
            $this -> display();
        }
    }

    //商品删除
    public function del(){
        //实例化模型
        $goods = D('Category');
        //接收商品id
        $gid = I('get.cat_id');
        //删除
        //show_bug($gid);
        //exit;
         $goods -> delete($gid);  //表示影响行数
        if($gid=1){
                   //$goods -> delete($gid);  //表示影响行数
            //成功
            $this -> redirect('showList',array(),2,'删除成功！☺');
        }else{
            //失败
            $this -> redirect('showList',array(),2,'删除失败！☹');
        }
    }
}