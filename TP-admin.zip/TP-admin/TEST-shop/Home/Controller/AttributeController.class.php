<?php
namespace Home\Controller;
//use Think\Controller;
use Tools\HomeController;
class AttributeController extends HomeController{
    //列表展示
    function showlist(){
        $daohang = array(
            'first'=>'属性管理',
            'second'=>'属性列表',
            'third'=>'添加',
            'third_url'=>U('tianjia'),
        );
        $this -> assign('daohang',$daohang);

        $goods = D('Attribute');
        $info = $goods ->order('attr_id desc')-> select();

        //数据的分页
        //先查询有多少记录
        $count = $goods -> count(); //返回值是数字
        //告诉分页类，一共有多少个记录和每页显示的记录数量
        $page = new \Think\Page($count,5);  //不需要参数
        //配置
        $page -> setConfig('first','首页');
        $page -> setConfig('prev','上一页');
        $page -> setConfig('next','下一页');
        $page -> setConfig('last','末页');
        $show = $page -> show();
        //查询
        $info = $goods -> limit($page -> firstRow.','.$page -> listRows) -> select();
        
        //$qq = new  \Model\QqModel();
        //show_bug($qq);
        //echo __SELF__;
        //echo __MODULE__;
        
        //把变量传递给模版
        $this -> assign('show',$show);


        //获得并传递商品属性列表信息到模板
        $info = D('Attribute')
            ->alias('a')
            ->join('__TYPE__ t on a.attr_id=t.type_id')
            ->field('a.*,t.type_name')
            ->select();
        $this -> assign('info',$info);

        /****获得全部的类型信息****/
        $typeinfo = D('Type')->select();
        $this -> assign('typeinfo',$typeinfo);
        /****获得全部的类型信息****/

        $this -> display();
    }
    
    function tianjia(){
        if(IS_POST){

            $Attribute = D('Attribute');
            $shuju = $Attribute -> create();
            if($Attribute->add($shuju)){
                $this -> success('添加属性成功',U('showlist'));
            }else{
                $this -> error('添加属性失败',U('tianjia'));
            }
        }else{
            $daohang = array(
                'first'=>'属性管理',
                'second'=>'添加属性',
                'third'=>'返回',
                'third_url'=>U('showlist'),
            );
            $this -> assign('daohang',$daohang);

            //获得“类型”并传递给模板
            $typeinfo = D('Type')->select();
            $this -> assign('typeinfo',$typeinfo);

            $this -> display();
        }
    }

    //根据typeid类型信息 获得对应的属性信息
    function getAttributeByType(){
        //接收get方式过来的typeid信息
        $typeid = I('get.typeid');

        //如果类型的值=0，则获取的属性信息不通过类型限制
        $cdt = array();
        if($typeid>0){
            $cdt['a.type_id']= $typeid;
        }

        //获得对应的属性信息
        $attrinfo = D('Attribute')
            ->alias('a')
            ->join('__TYPE__ t on a.type_id=t.type_id')
            ->field('a.*,t.type_name')
            ->where($cdt)
            ->select();
        //$attrinfo = array(
        //        0-》array(attr_id=>x,attr_name=>xx,attr_sel=>xx),
        //        1->array(attr_id=>x,attr_name=>xx,attr_sel=>xx),
        //        2->array(attr_id=>x,attr_name=>xx,attr_sel=>xx))
        echo json_encode($attrinfo); //[json,json,json]
        //[{"attr_id":"1","attr_name":"cpu","type_id":"2","attr_sel":"0","attr_write":"0","attr_vals":""},{"attr_id":"2","attr_name":"\u50cf\u7d20","type_id":"2","attr_sel":"0","attr_write":"0","attr_vals":""},{"attr_id":"3","attr_name":"\u989c\u8272","type_id":"2","attr_sel":"1","attr_write":"1","attr_vals":"\u767d\u8272,\u7eff\u8272,\u7ea2\u8272,\u9ed1\u8272"}]
    }

    //【添加商品】 根据typeid类型信息 获得对应的属性信息
   function getAttributeByType2(){
        //接收get方式过来的typeid信息
        $typeid = I('get.typeid');

        //如果类型的值=0，则获取的属性信息不通过类型限制
        $cdt = array();
        if($typeid>0){
            $cdt['a.type_id']= $typeid;
        }

        //获得对应的属性信息
        $attrinfo = D('Attribute')
            ->alias('a')
            ->join('__TYPE__ t on a.type_id=t.type_id')
            ->field('a.*,t.type_name')
            ->where($cdt)
            ->select();
        echo json_encode($attrinfo); //[json,json,json]
    }

    //【修改商品】 根据typeid类型信息 获得对应的属性信息
    function getAttributeByType3(){
        //接收get方式过来的typeid和goodsid信息
        $typeid = I('get.typeid');
        $goodsid = I('get.goodsid');

        //根据传递过来的“类型”、“商品”
        //判断是否存在属性信息
        //sp_goods_attr(goods_id,attr_id)-----sp_attrbute(attr_id,type_id)
        //判断当前的商品/类型是否存在对应的属性
        $attrinfo = D('GoodsAttr')
            ->alias('ga')
            ->join('__ATTRIBUTE__ a on ga.attr_id=a.attr_id')
            ->where(array('ga.goods_id'=>$goodsid,'a.type_id'=>$typeid))
            ->field('a.attr_id,a.attr_name,a.attr_sel,a.attr_vals,group_concat(ga.attr_value) attrvalues')
            ->group('a.attr_id')
            ->select();

        //通过"flag"表示当前属性信息的状态
        $info['flag'] = 0; //实体属性信息
        if(empty($attrinfo)){
            // 获得"空壳属性信息"
            $attrinfo = D('Attribute')
                ->where(array('type_id'=>$typeid))
                ->select();
            $info['flag'] = 1; //空壳属性信息
        }
        
        $info['data'] = $attrinfo;

        echo json_encode($info); //[json,json,json]
    }

     //商品修改
    function upd(){
        $goods_id = I('get.attr_id');
        $goods = new \Model\AttributeModel();
        if(IS_POST){
            //dump($_POST);
            //修改商品普通信息处理
            $shuju = $goods -> create();
            $shuju['upd_time'] = time();

            //富文本编辑器内容特殊处理
            $shuju['goods_introduce'] = \fanXSS($_POST['goods_introduce']);

            $this -> deal_logo($shuju); //实现商品logo图片处理
            $this -> deal_pics($shuju['attr_id']); //实现相册上传处理

            if($goods->save($shuju)){
                $this -> success('修改商品成功',U('showlist'),1);
            }else{
                $this -> error('修改商品失败',U('upd',array('attr_id'=>$goods_id)),1);
            }
        }else{
            $daohang = array(
                'first'=>'属性管理',
                'second'=>'修改属性',
                'third'=>'返回',
                'third_url'=>U('showlist'),
            );
            $this -> assign('daohang',$daohang);
            //根据$goods_id获得被修改商品的信息
            $info = $goods->find($goods_id);

            /****相册图片信息sp_goods_pics****/
            $picsinfo = D('GoodsPics')
                ->where(array('goods_id'=>$goods_id))
                ->select();
            $this -> assign('picsinfo',$picsinfo);
            /****相册图片信息****/

            /****获得“类型”并传递给模板****/
            $typeinfo = D('Type')->select();
            $this -> assign('typeinfo',$typeinfo);
            /****获得“类型”并传递给模板****/

            /****获得“第一级分类信息”并传递给模板****/
            $catinfoA = D('Category')
                ->where(array('cat_level'=>0))
                ->select();
            $this -> assign('catinfoA',$catinfoA);
            /****获得“第一级分类信息”并传递给模板****/

            /****获得商品的所有扩展分类信息****/
            $ext = D('GoodsCat')
                ->where(array('goods_id'=>$goods_id))
                ->field('group_concat(cat_id) as extids')
                ->find();
            //dump($ext);//array(1) {["extids"] => string(3) "5,6"}
            $extcatids = $ext['extids'];
            $this -> assign('extcatids',$extcatids);
            /****获得商品的所有扩展分类信息****/

            $this -> assign('info',$info);
            $this -> display();
        }
    }

    
}
