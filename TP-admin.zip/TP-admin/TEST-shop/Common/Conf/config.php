<?php
return array(
    //'配置项'=>'配置值'

    /* 数据库设置 */
    'DB_TYPE'               =>  'mysql',     // 数据库类型
    'DB_HOST'               =>  '45.124.27.18', // 服务器地址
    'DB_NAME'               =>  'dede',          // 数据库名
    'DB_USER'               =>  'h271265415',      // 用户名
    'DB_PWD'                =>  '123456',          // 密码
    'DB_PORT'               =>  '3306',        // 端口3306
    'DB_PREFIX'             =>  'dede_',    // 数据库表前缀
    'DB_PARAMS'             =>  array(), // 数据库连接参数   
    'DB_FIELDS_CACHE'       =>  true,        // 启用字段缓存
    'DB_CHARSET'            =>  'utf8',      // 数据库编码默认采用utf8
    'SHOW_PAGE_TRACE'       => true,
);